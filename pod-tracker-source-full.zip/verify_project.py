#!/usr/bin/env python3
"""Static project checks (does not replace an Android SDK build)."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).parent
files = list(root.glob('app/src/main/res/**/*.xml')) + [root / 'app/src/main/AndroidManifest.xml']
for item in files:
    ET.parse(item)

ids = set()
for item in root.glob('app/src/main/res/**/*.xml'):
    text = item.read_text()
    ids.update(re.findall(r'@\+id/(\w+)', text))

java_files = list(root.glob('app/src/main/java/**/*.java'))
source = '\n'.join(f.read_text() for f in java_files)
refs = set(re.findall(r'R\.id\.(\w+)', source))
missing = refs - ids
assert not missing, f'Missing Android resource IDs: {missing}'

resources = set()
for folder in ['drawable', 'layout', 'xml']:
    resources.update(p.stem for p in (root / 'app/src/main/res' / folder).glob('*.xml'))
missing_drawables = set(re.findall(r'R\.drawable\.(\w+)', source)) - resources
assert not missing_drawables, f'Missing drawables: {missing_drawables}'

for pod in 'abcd':
    for prefix in ['row', 'time', 'action', 'letter']:
        assert f'{prefix}_{pod}' in ids

assert all(f'"{pod}"' in source for pod in 'ABCD')
assert 'HHmm' in source and 'getBroadcast' in source
assert 'setOnClickPendingIntent(row, pending)' in source
assert 'getSharedPreferences' in source
print('Static checks passed: all XML parsed, all Java R.id/R.drawable references present, 4 pod buttons and 24-hour timestamps configured.')
print('NOTE: APK compilation still requires Android SDK/build-tools.')
