package com.grantshepherd.podtracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends Activity {
    private static final int BG = 0xFF0D1728;
    private static final int PANEL = 0xFF192D44;
    private static final int WHITE = 0xFFF5F9FC;
    private static final int MUTED = 0xFF9BB4C7;
    private static final int ACCENT = 0xFF9BE2E7;
    private static final int IN_COLOR = 0xFF187E9B;
    private static final int OUT_COLOR = 0xFFB66B4F;
    private boolean showingHistory = false;

    @Override public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        render();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private Button button(String title, int color, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setBackground(background(color, 10));
        b.setOnClickListener(click);
        return b;
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column();
        root.setPadding(dp(17), dp(20), dp(17), dp(32));
        scroll.addView(root);
        setContentView(scroll);

        TextView head = label("POD TIME TRACKER", 24, WHITE, true);
        root.addView(head);
        TextView shift = label("SHIFT STARTED  " + PodStore.dateTime(PodStore.currentShift(this)) + "  •  24-HOUR TIME", 12, ACCENT, true);
        shift.setPadding(0,dp(4),0,dp(14));
        root.addView(shift);

        if (showingHistory) {
            showHistory(root);
            return;
        }

        TextView instruction = label("Tap IN when entering a pod. Tap OUT when leaving. The home-screen widget works the same way.", 13, MUTED, false);
        instruction.setPadding(0,0,0,dp(15));
        root.addView(instruction);

        List<PodStore.Visit> list = PodStore.visits(this);
        long current = PodStore.currentShift(this);
        for (String pod : PodStore.PODS) {
            List<PodStore.Visit> podVisits = new ArrayList<>();
            for (PodStore.Visit v : list) {
                if (v.pod.equals(pod) && v.shift == current) podVisits.add(v);
            }
            addPod(root, pod, podVisits);
        }

        TextView hint = label("Times are captured on tap and saved on this phone. Records remain across midnight, app restarts, and device reboots.", 12, MUTED, false);
        hint.setPadding(0,dp(4),0,dp(14));
        root.addView(hint);

        addFullButton(root, "COPY CURRENT SHIFT", IN_COLOR, v -> copy(PodStore.shiftLog(this)));
        addFullButton(root, "SHARE SHIFT LOG", PANEL, v -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, PodStore.shiftLog(this));
            startActivity(Intent.createChooser(send, "Share pod log"));
        });
        addFullButton(root, "UNDO LAST TAP", PANEL, v -> {
            if (PodStore.undoLast(this)) {
                PodWidgetProvider.refreshAll(this);
                render();
                Toast.makeText(this,"Last tap undone",Toast.LENGTH_SHORT).show();
            } else Toast.makeText(this,"Nothing available to undo",Toast.LENGTH_SHORT).show();
        });
        addFullButton(root, "VIEW SAVED HISTORY", PANEL, v -> {
            showingHistory = true;
            render();
        });
        addFullButton(root, "START NEW SHIFT", OUT_COLOR, v -> askNewShift());

        TextView footer = label("All data stays local. This Android widget does not currently sync with the Base44 website.", 11, MUTED, false);
        footer.setPadding(0,dp(12),0,0);
        root.addView(footer);
    }

    private void addPod(LinearLayout root, String pod, List<PodStore.Visit> visits) {
        LinearLayout card = column();
        card.setPadding(dp(13),dp(12),dp(13),dp(12));
        card.setBackground(background(PANEL, 15));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1,-2);
        cardParams.bottomMargin=dp(10);
        root.addView(card, cardParams);

        LinearLayout header = row();
        card.addView(header);
        TextView title = label("POD " + pod, 19, WHITE, true);
        header.addView(title, new LinearLayout.LayoutParams(0,-2,1f));
        PodStore.Visit recent = visits.isEmpty() ? null : visits.get(visits.size()-1);
        boolean inside = recent != null && recent.exited == 0;
        Button toggle = button(inside ? "TAP OUT" : "TAP IN", inside ? OUT_COLOR : IN_COLOR, v -> {
            PodStore.Visit changed = PodStore.toggle(this,pod);
            if (changed != null) {
                PodWidgetProvider.refreshAll(this);
                render();
            } else Toast.makeText(this, "Could not save timestamp",Toast.LENGTH_LONG).show();
        });
        header.addView(toggle, new LinearLayout.LayoutParams(dp(120),dp(46)));

        String current = "----–----";
        if (recent != null) current = PodStore.shortVisit(recent);
        TextView latest = label(current + (inside ? "  •  INSIDE" : ""), 18, inside ? 0xFFA5EFCB : ACCENT, true);
        latest.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        latest.setPadding(0,dp(5),0,dp(3));
        card.addView(latest);

        if (visits.size() > 1) {
            StringBuilder earlier = new StringBuilder("Earlier: ");
            for (int i = 0; i < visits.size() - 1; i++) {
                if (i > 0) earlier.append(", ");
                earlier.append(PodStore.shortVisit(visits.get(i)));
            }
            TextView history = label(earlier.toString(), 12, MUTED, false);
            history.setTypeface(Typeface.MONOSPACE);
            card.addView(history);
        }
    }

    private void addFullButton(LinearLayout parent, String title, int color, View.OnClickListener click) {
        Button b = button(title,color,click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.bottomMargin = dp(9);
        parent.addView(b,lp);
    }

    private void showHistory(LinearLayout root) {
        addFullButton(root, "← BACK TO CURRENT SHIFT", IN_COLOR, v -> {
            showingHistory = false;
            render();
        });
        addFullButton(root, "COPY ALL SAVED HISTORY", PANEL, v -> copy(PodStore.fullHistory(this)));
        TextView text = label(PodStore.fullHistory(this),14,WHITE,false);
        text.setTypeface(Typeface.MONOSPACE);
        text.setBackground(background(PANEL,14));
        text.setPadding(dp(14),dp(14),dp(14),dp(14));
        root.addView(text);
    }

    private void askNewShift() {
        if (PodStore.hasOpenVisit(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Pod still marked IN")
                .setMessage("Tap OUT of every open pod before starting a new shift. No exit time will be invented.")
                .setPositiveButton("OK",(d,w)->{})
                .show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Start new shift?")
                .setMessage("The current view will start fresh. All previous pod records will remain saved in History.")
                .setNegativeButton("Cancel", (d,w)->{})
                .setPositiveButton("Start shift",(d,w)->{
                    if (PodStore.startNewShift(this)) {
                        PodWidgetProvider.refreshAll(this);
                        render();
                    } else Toast.makeText(this, "Could not start shift", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void copy(String body) {
        ClipboardManager manager = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        manager.setPrimaryClip(ClipData.newPlainText("Pod Time Tracker",body));
        Toast.makeText(this,"Log copied to clipboard",Toast.LENGTH_SHORT).show();
    }

    @Override public void onBackPressed() {
        if (showingHistory) {
            showingHistory=false;
            render();
        } else super.onBackPressed();
    }
}
