package com.grantshepherd.podtracker;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Entirely local storage; records do not leave the phone. */
public final class PodStore {
    private static final String PREFS = "pod_tracker_data";
    private static final String KEY_VISITS = "visits_json";
    private static final String KEY_SHIFT = "shift_started";
    private static final String KEY_LAST = "last_tap";
    public static final String[] PODS = { "A", "B", "C", "D" };

    private PodStore() {}

    public static final class Visit {
        public final String pod;
        public final long entered;
        public final long exited; // 0 means still IN
        public final long shift;

        Visit(String pod, long entered, long exited, long shift) {
            this.pod = pod;
            this.entered = entered;
            this.exited = exited;
            this.shift = shift;
        }

        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("pod", pod);
            o.put("entered", entered);
            o.put("exited", exited);
            o.put("shift", shift);
            return o;
        }
    }

    private static SharedPreferences pref(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized long currentShift(Context context) {
        SharedPreferences p = pref(context);
        long shift = p.getLong(KEY_SHIFT, 0);
        if (shift == 0) {
            shift = System.currentTimeMillis();
            p.edit().putLong(KEY_SHIFT, shift).commit();
        }
        return shift;
    }

    public static synchronized List<Visit> visits(Context context) {
        List<Visit> list = new ArrayList<>();
        String raw = pref(context).getString(KEY_VISITS, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                String pod = o.optString("pod", "");
                if (!validPod(pod)) continue;
                long entered = o.optLong("entered", 0);
                if (entered <= 0) continue;
                list.add(new Visit(pod, entered, o.optLong("exited", 0), o.optLong("shift", 0)));
            }
        } catch (JSONException ignored) {
            // Invalid storage must never crash the widget.
        }
        return list;
    }

    private static boolean save(Context context, List<Visit> list, JSONObject lastAction) {
        JSONArray array = new JSONArray();
        for (Visit v : list) {
            try { array.put(v.toJson()); } catch (JSONException ignored) { }
        }
        SharedPreferences.Editor e = pref(context).edit().putString(KEY_VISITS, array.toString());
        if (lastAction == null) e.remove(KEY_LAST);
        else e.putString(KEY_LAST, lastAction.toString());
        return e.commit();
    }

    public static boolean validPod(String pod) {
        return "A".equals(pod) || "B".equals(pod) || "C".equals(pod) || "D".equals(pod);
    }

    public static synchronized Visit latest(Context context, String pod) {
        long shift = currentShift(context);
        List<Visit> list = visits(context);
        for (int i = list.size()-1; i >= 0; i--) {
            Visit v = list.get(i);
            if (v.shift == shift && v.pod.equals(pod)) return v;
        }
        return null;
    }

    public static synchronized boolean hasOpenVisit(Context context) {
        long shift = currentShift(context);
        for (Visit v : visits(context)) {
            if (v.shift == shift && v.exited == 0) return true;
        }
        return false;
    }

    /** Returns the new entry/exit visit, or null for an invalid pod. */
    public static synchronized Visit toggle(Context context, String pod) {
        if (!validPod(pod)) return null;
        long shift = currentShift(context);
        long now = System.currentTimeMillis();
        List<Visit> list = visits(context);
        int open = -1;
        for (int i = list.size() - 1; i >= 0; i--) {
            Visit v = list.get(i);
            if (v.shift == shift && v.pod.equals(pod) && v.exited == 0) {
                open = i;
                break;
            }
        }
        Visit result;
        String action;
        if (open >= 0) {
            Visit prior = list.get(open);
            result = new Visit(prior.pod, prior.entered, now, prior.shift);
            list.set(open, result);
            action = "OUT";
        } else {
            result = new Visit(pod, now, 0, shift);
            list.add(result);
            action = "IN";
        }
        JSONObject last = new JSONObject();
        try {
            last.put("pod", pod);
            last.put("entered", result.entered);
            last.put("time", now);
            last.put("action", action);
            last.put("shift", shift);
        } catch (JSONException ignored) { }
        return save(context, list, last) ? result : null;
    }

    /** Undo only the most recent tap so earlier timestamps cannot be silently changed. */
    public static synchronized boolean undoLast(Context context) {
        String raw = pref(context).getString(KEY_LAST, null);
        if (raw == null) return false;
        try {
            JSONObject last = new JSONObject(raw);
            String pod = last.getString("pod");
            long entered = last.getLong("entered");
            long time = last.getLong("time");
            long shift = last.getLong("shift");
            if (shift != currentShift(context)) return false;
            List<Visit> list = visits(context);
            for (int i = list.size()-1; i >= 0; i--) {
                Visit v = list.get(i);
                if (!v.pod.equals(pod) || v.entered != entered || v.shift != shift) continue;
                if (last.getString("action").equals("IN") && v.exited == 0) {
                    list.remove(i);
                } else if (last.getString("action").equals("OUT") && v.exited == time) {
                    list.set(i, new Visit(v.pod, v.entered, 0, v.shift));
                } else {
                    return false;
                }
                return save(context, list, null);
            }
        } catch (JSONException ignored) { }
        return false;
    }

    /** Starts an empty shift view but does NOT delete old records. Requires all pods OUT. */
    public static synchronized boolean startNewShift(Context context) {
        if (hasOpenVisit(context)) return false;
        long newShift = System.currentTimeMillis();
        // A distinct shift id even for two button presses in one millisecond.
        if (newShift <= currentShift(context)) newShift = currentShift(context) + 1;
        return pref(context).edit().putLong(KEY_SHIFT, newShift).remove(KEY_LAST).commit();
    }

    public static String time(long millis) {
        if (millis == 0) return "----";
        return new SimpleDateFormat("HHmm", Locale.US).format(new Date(millis));
    }

    public static String date(long millis) {
        return new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(new Date(millis));
    }

    public static String dateTime(long millis) {
        return new SimpleDateFormat("MM/dd/yyyy HHmm", Locale.US).format(new Date(millis));
    }

    public static String shortVisit(Visit v) {
        if (v == null) return "----–----";
        return time(v.entered) + "–" + (v.exited == 0 ? "IN" : time(v.exited));
    }

    public static synchronized String shiftLog(Context context) {
        long shift = currentShift(context);
        List<Visit> list = visits(context);
        StringBuilder sb = new StringBuilder();
        sb.append("POD TIME TRACKER • SHIFT ").append(dateTime(shift)).append('\n');
        for (String pod : PODS) {
            sb.append(pod).append(' ');
            boolean any = false;
            for (Visit v : list) {
                if (!v.pod.equals(pod) || v.shift != shift) continue;
                if (any) sb.append(", ");
                sb.append(shortVisit(v));
                any = true;
            }
            if (!any) sb.append("----–----");
            sb.append('\n');
        }
        return sb.toString().trim();
    }

    public static synchronized String fullHistory(Context context) {
        List<Visit> list = visits(context);
        StringBuilder sb = new StringBuilder("ALL SAVED POD VISITS\n");
        long prevShift = -1;
        // Show oldest first in chronological order.
        for (Visit v : list) {
            if (v.shift != prevShift) {
                sb.append("\nSHIFT: ").append(dateTime(v.shift)).append('\n');
                prevShift = v.shift;
            }
            sb.append(v.pod).append("  ").append(date(v.entered)).append("  ").append(shortVisit(v)).append('\n');
        }
        if (list.isEmpty()) sb.append("No visits recorded yet.");
        return sb.toString().trim();
    }
}
