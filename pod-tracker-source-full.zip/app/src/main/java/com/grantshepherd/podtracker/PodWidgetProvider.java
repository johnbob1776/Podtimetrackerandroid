package com.grantshepherd.podtracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;

public final class PodWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_TOGGLE = "com.grantshepherd.podtracker.TOGGLE_POD";
    public static final String EXTRA_POD = "pod";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (ACTION_TOGGLE.equals(intent.getAction())) {
            String pod = intent.getStringExtra(EXTRA_POD);
            if (PodStore.validPod(pod)) {
                PodStore.toggle(context, pod);
                refreshAll(context);
            }
            return;
        }
        super.onReceive(context, intent);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            manager.updateAppWidget(id, build(context, id));
        }
    }

    static void refreshAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, PodWidgetProvider.class));
        for (int id : ids) manager.updateAppWidget(id, build(context, id));
    }

    private static RemoteViews build(Context context, int widgetId) {
        String pkg = context.getPackageName();
        RemoteViews views = new RemoteViews(pkg, R.layout.pod_widget);
        views.setTextViewText(R.id.widget_shift, PodStore.date(PodStore.currentShift(context)));
        for (int i = 0; i < PodStore.PODS.length; i++) {
            String pod = PodStore.PODS[i];
            PodStore.Visit visit = PodStore.latest(context, pod);
            boolean inside = visit != null && visit.exited == 0;
            int row = rowId(i);
            int timestamp = timeId(i);
            int actionId = actionId(i);
            views.setTextViewText(timestamp, PodStore.shortVisit(visit));
            views.setTextViewText(actionId, inside ? "OUT" : "IN");
            views.setInt(row, "setBackgroundResource", inside ? R.drawable.row_active_bg : R.drawable.row_bg);
            views.setInt(actionId, "setBackgroundResource", inside ? R.drawable.out_button : R.drawable.in_button);
            views.setTextColor(timestamp, inside ? Color.rgb(159, 245, 215) : Color.rgb(226,244,255));

            Intent toggle = new Intent(context, PodWidgetProvider.class);
            toggle.setAction(ACTION_TOGGLE);
            toggle.putExtra(EXTRA_POD, pod);
            // Unique per-widget and per-pod, so rapid taps never collide across rows.
            int requestCode = widgetId * 10 + i;
            PendingIntent pending = PendingIntent.getBroadcast(context, requestCode, toggle,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(row, pending);
            views.setOnClickPendingIntent(actionId, pending);
        }

        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending = PendingIntent.getActivity(context, widgetId + 900000, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_footer, openPending);
        views.setOnClickPendingIntent(R.id.widget_title, openPending);
        return views;
    }

    private static int rowId(int i) {
        switch (i) {
            case 0: return R.id.row_a;
            case 1: return R.id.row_b;
            case 2: return R.id.row_c;
            default: return R.id.row_d;
        }
    }
    private static int timeId(int i) {
        switch (i) {
            case 0: return R.id.time_a;
            case 1: return R.id.time_b;
            case 2: return R.id.time_c;
            default: return R.id.time_d;
        }
    }
    private static int actionId(int i) {
        switch (i) {
            case 0: return R.id.action_a;
            case 1: return R.id.action_b;
            case 2: return R.id.action_c;
            default: return R.id.action_d;
        }
    }
}
