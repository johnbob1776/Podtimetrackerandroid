# Pod Time Tracker — real Android home-screen widget

A native Android app **with a genuine, tappable AppWidget**. This is not a website shortcut. It is designed for a Samsung Galaxy phone, including the Galaxy S24 Ultra.

## How it works

- Put the **Pod Time Tracker** widget on your home screen.
- Tap **IN** on the A, B, C or D row to log entry. The widget immediately updates to show `A 1230–IN` with an **OUT** button.
- Tap **OUT** on that row to log exit. It updates to `A 1230–1245`.
- Each new entry starts an additional visit to that same pod; earlier entries remain in the shift history.
- Tap **OPEN SHIFT LOG** to view all visits, copy/share the formatted log, undo the very last tap, or start a new shift.
- Use **START NEW SHIFT** at the beginning of your next shift. No history is deleted. You must record OUT for any active pod first; the app does **not** invent exit times.
- Timestamps use the phone's current time zone and 24-hour military-time format `HHmm`, and the data survives closing the app, midnight and restarting the phone.

**Privacy:** No account, network, or storage permissions. All entries are stored locally on the phone. The website version created in Base44 is **separate** and does not sync with the Android app.

## Installing it on your Samsung

You need to **build the APK first**. This ZIP contains full Android source, not an already compiled APK, because the current build environment has no Android SDK. Two options:

### Option 1: Android Studio (Windows, macOS, Linux)

1. Unzip this project and open the `PodTimeTrackerAndroid` folder in **Android Studio**.
2. Allow Android Studio to download Gradle/Android SDK packages and sync the project. Select local Gradle 8.9 if it asks because the ZIP intentionally contains no Gradle wrapper binary.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Copy `app/build/outputs/apk/debug/app-debug.apk` onto your Samsung phone.
5. On your phone, open the APK and approve "Install unknown apps" for that source if prompted. Only install APKs you built yourself or obtained from a source you trust.

### Option 2: GitHub Actions (cloud build, no computer-side Android SDK)

1. Create a private GitHub repository and upload **the contents** of this source folder, including `.github/workflows/build-android-apk.yml`.
2. In the GitHub repository choose **Actions → Build installable Android APK → Run workflow**. A `push` to the main branch also triggers a build.
3. When the run succeeds, download the artifact named `PodTimeTracker-debug-APK` from that run and unzip it to get `app-debug.apk`.
4. Transfer the APK to the Samsung phone and open it to install.

**Note on APK updates:** A debug APK is signed with a machine-generated debug key. APKs built on different computers or separate GitHub runners usually have different signatures, so they may not install as updates to one another. Keep your original build key or later create a stable signed release; otherwise uninstalling an older build may delete local logs. Copy your history first before uninstalling.

## Put the actual widget on the home screen

1. Long-press an empty area of the Samsung home screen.
2. Choose **Widgets**.
3. Search **Pod Time Tracker**.
4. Drag the widget onto a home-screen page. If needed, resize it to roughly **4 columns by 4 rows** or larger so all four pod buttons fit.
5. Tap the IN/OUT button for the desired pod without opening the app.

## Important operational notes

- The widget records the current device time when Android handles the tap, not a manually entered or retrospectively estimated time.
- The widget does **not** automatically close another pod when you enter a different pod. This avoids creating a fictitious exit time; be sure to tap OUT yourself.
- The app is a personal log aid, not a replacement for your agency's officially required records or access-control systems.
- Don't uninstall or clear app data without first copying/sharing your saved history.
