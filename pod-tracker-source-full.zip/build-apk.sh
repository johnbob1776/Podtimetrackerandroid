#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Install Gradle 8.9 (or open the project in Android Studio), then rerun.' >&2
  exit 1
fi
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
gradle --no-daemon :app:assembleDebug
printf 'APK: app/build/outputs/apk/debug/app-debug.apk\n'
